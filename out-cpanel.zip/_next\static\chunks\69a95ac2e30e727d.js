__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/f5b91efee5125263.js",
  "static/chunks/turbopack-b066f556a32a53b1.js"
])
