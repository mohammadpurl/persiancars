__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/21c24d2aacb6cefd.js",
  "static/chunks/turbopack-5d9afc9780cb85f7.js"
])
