__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/21c24d2aacb6cefd.js",
  "static/chunks/turbopack-cf8eefc7bc0ffb9e.js"
])
